package com.hemasundar.nocode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NocodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
