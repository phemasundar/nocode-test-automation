package com.hemasundar.nocode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NocodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(NocodeApplication.class, args);
	}

}
